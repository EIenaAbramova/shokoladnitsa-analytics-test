import fs from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {SpreadsheetFile,FileBlob} from '@oai/artifact-tool';
const root=new URL('../',import.meta.url);
const w=await SpreadsheetFile.importXlsx(await FileBlob.load(fileURLToPath(new URL('outputs/Шоколадница_Excel.xlsx',root))));
for(const [s,r,n] of [['Порции','A1:I21','excel1'],['ФИО','A1:K21','excel2'],['Общий итог','A1:N21','excel3']]){
 console.log((await w.inspect({kind:'table',range:`'${s}'!A1:C3`,include:'values,formulas',maxChars:700})).ndjson);
 const b=await w.render({sheetName:s,autoCrop:"all",scale:1.4,format:'png'});
 await fs.writeFile(new URL('qa/'+n+'.png',root),new Uint8Array(await b.arrayBuffer()));
}
