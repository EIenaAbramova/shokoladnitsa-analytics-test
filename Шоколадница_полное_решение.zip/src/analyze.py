"""Extract the clean task inputs and independently calculate control results."""
from pathlib import Path
import json, csv, shutil, hashlib
from collections import Counter, defaultdict
import openpyxl

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT.parent

def main():
    for name in ['data','outputs','qa','docs','sql']:
        (ROOT/name).mkdir(exist_ok=True)
    names = {'excel_source.xlsx':'Тест по Excelо_1.xlsx',
             'data_source.xlsx':'Тест по данным_1.xlsx',
             'sql_source.xlsx':'тест по SQL_1.xlsx'}
    manifest = []
    for dst, src in names.items():
        target = ROOT/'data'/dst
        if (SOURCE/src).exists(): shutil.copy2(SOURCE/src,target)
        manifest.append({'file':dst,'original_name':src,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
    (ROOT/'data/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    book = openpyxl.load_workbook(ROOT/'data/data_source.xlsx',data_only=True)
    rows = [list(r[:5]) for r in list(book.active.values)[1:] if r[0] is not None]
    assert len(rows)==648 and not any(None in r for r in rows)
    assert len(set(tuple(r[:3]) for r in rows))==len(rows)
    cafes = sorted(set(r[0] for r in rows),key=lambda x:int(x[4:]))
    assert all(Counter((r[1],r[2]) for r in rows if r[0]==c)==Counter((y,m) for y in [2018,2019] for m in range(1,13)) for c in cafes)
    def aggregate(rs):
        return [sum(r[3] for r in rs),sum(r[4] for r in rs)]
    totals={str(y):aggregate([r for r in rows if r[1]==y]) for y in [2018,2019]}
    objects=[]
    for c in cafes:
        r0,n0=aggregate([r for r in rows if r[0]==c and r[1]==2018])
        r1,n1=aggregate([r for r in rows if r[0]==c and r[1]==2019])
        a0,a1=r0/n0,r1/n1
        # Symmetric decomposition: split the interaction equally.
        traffic=(n1-n0)*(a0+a1)/2
        ticket=(a1-a0)*(n0+n1)/2
        assert abs(traffic+ticket-(r1-r0))<1e-7
        objects.append(dict(cafe=c,revenue2018=r0,revenue2019=r1,delta=r1-r0,growth=r1/r0-1,
                            checks2018=n0,checks2019=n1,ticket2018=a0,ticket2019=a1,
                            traffic_effect=traffic,ticket_effect=ticket))
    r0,n0=totals['2018'];r1,n1=totals['2019']
    delta=r1-r0
    summary=dict(revenue2018=r0,revenue2019=r1,delta=delta,growth=r1/r0-1,
                 checks2018=n0,checks2019=n1,checks_growth=n1/n0-1,
                 ticket2018=r0/n0,ticket2019=r1/n1,ticket_growth=(r1/n1)/(r0/n0)-1,
                 traffic_effect=sum(o['traffic_effect'] for o in objects),
                 ticket_effect=sum(o['ticket_effect'] for o in objects),
                 network_traffic_effect=(n1-n0)*(r0/n0+r1/n1)/2,
                 network_ticket_effect=(r1/n1-r0/n0)*(n0+n1)/2)
    excel=openpyxl.load_workbook(ROOT/'data/excel_source.xlsx',data_only=False)
    ex1=[list(r[:3]) for r in list(excel.worksheets[0].values)[1:] if r[0]]
    ex2=[r[0] for r in list(excel.worksheets[1].values)[1:] if r[0]]
    ex3=[[r[0],r[1],r[2]] for r in list(excel.worksheets[2].values)[1:20]]
    excel_total=sum(r[1] for r in ex1 if r[2] in ['пн','вт','ср'])
    ex3_total=sum(r[2] for r in ex3 if r[1])
    months=[]
    for m in range(1,13):
        v0,nm0=aggregate([r for r in rows if r[1]==2018 and r[2]==m])
        v1,nm1=aggregate([r for r in rows if r[1]==2019 and r[2]==m])
        months.append([m,v0,v1,v1-v0,nm0,nm1])
    payload=dict(rows=rows,cafes=cafes,objects=objects,summary=summary,months=months,
                 excel1=ex1,excel2=ex2,excel3=ex3,excel1_total=excel_total,excel3_total=ex3_total)
    (ROOT/'qa/analysis.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
    with (ROOT/'outputs/cafe_contributions.csv').open('w',encoding='utf-8-sig',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=objects[0].keys());writer.writeheader();writer.writerows(objects)
    print(json.dumps(dict(summary=summary,top=sorted(objects,key=lambda x:x['delta'],reverse=True)[:5],bottom=sorted(objects,key=lambda x:x['delta'])[:5],excel1_total=excel_total,excel3_total=ex3_total),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
