import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {Workbook,SpreadsheetFile,FileBlob} from '@oai/artifact-tool';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const a=JSON.parse(await fs.readFile(path.join(root,'qa/analysis.json'),'utf8'));
const brown='#543728',cream='#F3E9DE',ink='#302820';
const put=(s,c,v)=>s.getRange(c).values=[[v]];
const fx=(s,c,v)=>s.getRange(c).formulas=[[v]];
function base(s,range){s.showGridLines=false;s.getRange(range).format.font={name:'Arial',size:11,color:ink};s.getRange(range).format.rowHeight=23;s.getRange(range).format.verticalAlignment='center';}
function head(s,r){s.getRange(r).format={fill:brown,font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},wrapText:true,horizontalAlignment:'center',verticalAlignment:'center',rowHeight:48};}
function title(s,c,t){put(s,c,t);s.getRange(c).format.font={name:'Arial',size:16,bold:true,color:brown};s.getRange(c).format.rowHeight=32;}
async function save(w,name,renders){w.recalculate();const errors=await w.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:50},summary:name});await fs.writeFile(path.join(root,'qa',name+'.checks.json'),errors.ndjson);for(const [s,r,id]of renders){const b=await w.render({sheetName:s,range:r,scale:1.4,format:'png'});await fs.writeFile(path.join(root,'qa',id+'.png'),new Uint8Array(await b.arrayBuffer()));}await(await SpreadsheetFile.exportXlsx(w)).save(path.join(root,'outputs',name+'.xlsx'));}

// Complete the original blank Excel assignment in place on a copy.
const ex=Workbook.create();for(const n of ['Порции','ФИО','Общий итог'])ex.worksheets.add(n);
ex.worksheets.getItem('Порции').getRange('A1:C1').values=[['Кафе','Кол-во порций','День недели']];ex.worksheets.getItem('Порции').getRange('A2:C20').values=a.excel1;
ex.worksheets.getItem('ФИО').getRange('A1').values=[['ФИО']];ex.worksheets.getItem('ФИО').getRange('A2:A21').values=a.excel2.map(x=>[x]);
ex.worksheets.getItem('ФИО').getRange('D1:E1').values=[['ФИ','О']];ex.worksheets.getItem('ФИО').getRange('H1').values=[['Фамилия И.О.']];
put(ex.worksheets.getItem('ФИО'),'K2','1. Разделить ФИО на «ФИ» и «О».');put(ex.worksheets.getItem('ФИО'),'K3','2. Получить формат «Фамилия И.О.».');
ex.worksheets.getItem('Общий итог').getRange('A1:C1').values=[['Строка','Кафе','Кол-во порций']];
for(let i=0;i<a.excel3.length;i++){const row=a.excel3[i],r=i+2;put(ex.worksheets.getItem('Общий итог'),`A${r}`,row[0]);put(ex.worksheets.getItem('Общий итог'),`B${r}`,row[1]);if(typeof row[2]==='string'&&row[2].startsWith('='))fx(ex.worksheets.getItem('Общий итог'),`C${r}`,row[2]);else put(ex.worksheets.getItem('Общий итог'),`C${r}`,row[2]);}
let s=ex.worksheets.getItem('Порции');base(s,'A1:K25');
s.getRange('A1:C20').format.columnWidth=18;head(s,'A1:C1');
s.getRange('E2:K5').unmerge();s.getRange('E2:K5').clear({applyTo:'all'});
title(s,'E2','Порции по кофейням');put(s,'E3','Только понедельник, вторник и среда');
s.getRange('E3:K3').merge();s.getRange('E3:K3').format.font={name:'Arial',size:11,italic:true,color:ink};
s.getRange('E5:I5').values=[['Кафе','пн','вт','ср','Итого']];head(s,'E5:I5');
s.getRange('E5:I21').format.columnWidth=16;
const cafes=[...new Set(a.excel1.map(r=>r[0]))].sort((x,y)=>Number(x.slice(4))-Number(y.slice(4)));
for(let i=0;i<cafes.length;i++){let r=i+6;put(s,`E${r}`,cafes[i]);for(const col of ['F','G','H'])fx(s,`${col}${r}`,`=SUMIFS($B$2:$B$20,$A$2:$A$20,$E${r},$C$2:$C$20,${col}$5)`);fx(s,`I${r}`,`=SUM(F${r}:H${r})`);}
let er=6+cafes.length;put(s,`E${er}`,'Итого');for(const c of ['F','G','H','I'])fx(s,`${c}${er}`,`=SUM(${c}6:${c}${er-1})`);s.getRange(`E${er}:I${er}`).format.fill=cream;s.getRange('F6:I21').setNumberFormat('#,##0');
if(s.getRange(`I${er}`).values[0][0]!==a.excel1_total)throw Error('Excel task1 mismatch');
s=ex.worksheets.getItem('ФИО');base(s,'A1:K23');s.getRange('A1:A21').format.columnWidth=34;s.getRange('D1:D21').format.columnWidth=27;s.getRange('E1:E21').format.columnWidth=22;s.getRange('H1:H21').format.columnWidth=27;s.getRange('K1:K5').format.columnWidth=55;s.getRange('K1:K5').format.wrapText=true;s.getRange('K2:K3').format.rowHeight=65;
for(const c of ['A1','D1:E1','H1'])head(s,c);
for(let r=2;r<=21;r++){
 const norm=`TRIM(SUBSTITUTE(A${r},CHAR(160)," "))`;
 const second=`FIND(" ",${norm},FIND(" ",${norm})+1)`;
 fx(s,`D${r}`,`=LEFT(${norm},${second}-1)`);
 fx(s,`E${r}`,`=MID(${norm},${second}+1,999)`);
 fx(s,`H${r}`,`=LEFT(D${r},FIND(" ",D${r})-1)&" "&MID(D${r},FIND(" ",D${r})+1,1)&"."&LEFT(E${r},1)&"."`);
}
s=ex.worksheets.getItem('Общий итог');base(s,'A1:N22');s.getRange('A1:C20').format.columnWidth=20;head(s,'A1:C1');
s.getRange('E3:F3').unmerge();s.getRange('E3:F3').clear({applyTo:'all'});put(s,'E3','Всего порций');s.getRange('E1:E6').format.columnWidth=23;s.getRange('G1:G6').format.columnWidth=20;
const table=s.tables.add('A1:C20',true,'Portions');table.showBandedRows=true;
// Sum details with a cafe name; subtotal rows have an empty cafe field.
fx(s,'G3','=SUMIFS(Portions[Кол-во порций],Portions[Кафе],"<>")');s.getRange('G3').setNumberFormat('#,##0');s.getRange('G3').format.font={name:'Arial',size:16,bold:true,color:brown};
s.getRange('J3:N6').unmerge();s.getRange('J3:N6').clear({applyTo:'all'});s.getRange('J3:N6').merge();put(s,'J3','Добавляйте записи внутри таблицы или через Tab в её последней ячейке. Для деталей заполняйте «Кафе». Строки «Сумма Итог» оставляйте без кафе.');s.getRange('J3:N6').format.wrapText=true;s.getRange('J3:N6').format.verticalAlignment='top';
if(s.getRange('G3').values[0][0]!==a.excel3_total)throw Error('Excel task3 mismatch '+JSON.stringify(s.getRange('G3').values));
table.rows.add(null,[[null,'Кафе3',100]]);fx(s,'G3','=SUMIFS(Portions[Кол-во порций],Portions[Кафе],"<>")');ex.recalculate();if(s.getRange('G3').values[0][0]!==a.excel3_total+100)throw Error('Table expansion failed '+JSON.stringify(s.getRange('G3').values));
// Re-import the original third sheet workflow is avoided; remove the test detail via clear then shrink not needed.
// Leave the appended row blank as an ordinary empty input row inside the table.
s.getRange('A21:C21').clear({applyTo:'contents'});
await save(ex,'Шоколадница_Excel',[['Порции','A1:I21','excel1'],['ФИО','A1:K21','excel2'],['Общий итог','A1:N21','excel3']]);

const w=Workbook.create();for(const n of ['Итоги','Объекты','По месяцам','Данные'])w.worksheets.add(n);
s=w.worksheets.getItem('Данные');base(s,'A1:E649');s.getRange('A1:E649').format.columnWidth=21;head(s,'A1:E1');s.getRange('A1:E1').values=[['Объект','Год','Месяц','Выручка, руб.','Количество чеков']];s.getRange('A2:E649').values=a.rows;s.getRange('D2:D649').setNumberFormat('#,##0.00');s.freezePanes.freezeRows(1);s.tables.add('A1:E649',true,'RevenueData');
s=w.worksheets.getItem('Объекты');base(s,'A1:P34');title(s,'A2','Вклад кофеен в изменение выручки');s.getRange('A4:P4').values=[['Кафе','Выручка 2018, руб.','Выручка 2019, руб.','Изменение, руб.','Изменение, %','Чеки 2018','Чеки 2019','Изменение чеков','Изменение чеков, %','Средний чек 2018, руб.','Средний чек 2019, руб.','Изменение ср. чека, %','Эффект числа чеков, руб.','Эффект среднего чека, руб.','Расхождение, руб.','Вклад в рост сети, п.п.']];head(s,'A4:P4');s.getRange('A4:P32').format.columnWidth=19;s.getRange('A4:A32').format.columnWidth=15;s.getRange('A4:P4').format.rowHeight=66;
const objects=[...a.objects].sort((x,y)=>y.delta-x.delta);
for(let i=0;i<objects.length;i++){
 const r=i+5;put(s,`A${r}`,objects[i].cafe);
 for(const [c,y,src] of [['B',2018,'D'],['C',2019,'D'],['F',2018,'E'],['G',2019,'E']])fx(s,`${c}${r}`,`=SUMIFS('Данные'!$${src}$2:$${src}$649,'Данные'!$A$2:$A$649,$A${r},'Данные'!$B$2:$B$649,${y})`);
 const formulas={D:`C${r}-B${r}`,E:`D${r}/B${r}`,H:`G${r}-F${r}`,I:`H${r}/F${r}`,J:`B${r}/F${r}`,K:`C${r}/G${r}`,L:`K${r}/J${r}-1`,M:`H${r}*(J${r}+K${r})/2`,N:`(K${r}-J${r})*(F${r}+G${r})/2`,O:`ROUND(M${r}+N${r}-D${r},8)`,P:`D${r}/$B$32*100`};
 for(const [c,f]of Object.entries(formulas))fx(s,`${c}${r}`,'='+f);
}
put(s,'A32','Итого');for(const c of ['B','C','D','F','G','H','M','N','O','P'])fx(s,`${c}32`,`=SUM(${c}5:${c}31)`);for(const [c,f]of Object.entries({E:'D32/B32',I:'H32/F32',J:'B32/F32',K:'C32/G32',L:'K32/J32-1'}))fx(s,`${c}32`,'='+f);
s.getRange('B5:P32').setNumberFormat('#,##0.00');for(const c of ['E','I','L'])s.getRange(`${c}5:${c}32`).setNumberFormat('0.0%');s.getRange('F5:H32').setNumberFormat('#,##0');s.getRange('A32:P32').format.fill=cream;s.freezePanes.freezeRows(4);s.freezePanes.freezeColumns(1);s.getRange('D5:D31').conditionalFormats.add('dataBar',{color:'#B47C55'});
s=w.worksheets.getItem('По месяцам');base(s,'A1:G18');title(s,'A2','Динамика по месяцам');s.getRange('A4:G4').values=[['Месяц','Выручка 2018, руб.','Выручка 2019, руб.','Изменение, руб.','Изменение, %','Чеки 2018','Чеки 2019']];head(s,'A4:G4');s.getRange('A4:G17').format.columnWidth=23;
for(let m=1;m<=12;m++){let r=m+4;put(s,`A${r}`,m);for(const [c,y,v]of [['B',2018,'D'],['C',2019,'D'],['F',2018,'E'],['G',2019,'E']])fx(s,`${c}${r}`,`=SUMIFS('Данные'!$${v}$2:$${v}$649,'Данные'!$B$2:$B$649,${y},'Данные'!$C$2:$C$649,$A${r})`);fx(s,`D${r}`,`=C${r}-B${r}`);fx(s,`E${r}`,`=D${r}/B${r}`);}
put(s,'A17','Итого');for(const c of ['B','C','D','F','G'])fx(s,`${c}17`,`=SUM(${c}5:${c}16)`);fx(s,'E17','=D17/B17');s.getRange('B5:D17').setNumberFormat('#,##0.00');s.getRange('E5:E17').setNumberFormat('0.0%');s.getRange('F5:G17').setNumberFormat('#,##0');s.getRange('A17:G17').format.fill=cream;
s=w.worksheets.getItem('Итоги');base(s,'A1:M38');title(s,'A2','Шоколадница: итоги 2019 года');s.getRange('A1:A38').format.columnWidth=35;s.getRange('B1:D38').format.columnWidth=21;s.getRange('E1:M38').format.columnWidth=12;
s.getRange('A4:D4').values=[['Показатель','2018','2019','Изменение']];head(s,'A4:D4');
for(const [r,label,b,c,d]of [[5,'Выручка, руб.','B32','C32','E32'],[6,'Количество чеков','F32','G32','I32'],[7,'Средний чек, руб.','J32','K32','L32']]){put(s,`A${r}`,label);for(const [col,ref]of [['B',b],['C',c],['D',d]])fx(s,`${col}${r}`,`='Объекты'!${ref}`);}
s.getRange('B5:C7').setNumberFormat('#,##0.00');s.getRange('B6:C6').setNumberFormat('#,##0');s.getRange('D5:D7').setNumberFormat('0.0%');
for(const [r,label,ref]of [[10,'Изменение выручки, руб.','D32'],[12,'Эффект числа чеков, руб.','M32'],[13,'Эффект среднего чека, руб.','N32'],[15,'Проверка разложения, руб.','O32']]){put(s,`A${r}`,label);fx(s,`B${r}`,`='Объекты'!${ref}`);s.getRange(`B${r}`).setNumberFormat('#,##0.00');}
s.getRange('A17:D19').merge();put(s,'A17','Эффекты рассчитаны внутри каждой кофейни симметричным методом, затем сложены по сети. Средний чек — выручка / число чеков.');s.getRange('A17:D19').format.wrapText=true;s.getRange('A17:D19').format.verticalAlignment='top';
const chart=s.charts.add('line',w.worksheets.getItem('По месяцам').getRange('A4:C16'));chart.title='Выручка по месяцам';chart.setPosition('F4','M19');chart.titleTextStyle.typeface='Arial';chart.titleTextStyle.fontSize=14;chart.xAxis={axisType:'textAxis',textStyle:{typeface:'Arial',fontSize:10}};chart.yAxis={numberFormatCode:'0.0,," млн"',numberFormatSourceLinked:false,textStyle:{typeface:'Arial',fontSize:10}};
s.getRange('A22:D22').values=[['Рост выручки','Вклад, руб.','Падение выручки','Вклад, руб.']];head(s,'A22:D22');const bottom=[...objects].sort((x,y)=>x.delta-y.delta);
for(let i=0;i<5;i++){let r=i+23;let br=objects.findIndex(o=>o.cafe===bottom[i].cafe)+5;fx(s,`A${r}`,`='Объекты'!A${i+5}`);fx(s,`B${r}`,`='Объекты'!D${i+5}`);fx(s,`C${r}`,`='Объекты'!A${br}`);fx(s,`D${r}`,`='Объекты'!D${br}`);}s.getRange('B23:B27').setNumberFormat('#,##0.00');s.getRange('D23:D27').setNumberFormat('#,##0.00');
s.getRange('A30:M32').merge();put(s,'A30','Главный риск: снижение числа чеков. Рост среднего чека компенсировал падение объёма операций. Проверить загрузку и режим работы кофеен 15–20, а также причины скачка среднего чека в кофейнях 7–10.');s.getRange('A30:M32').format.wrapText=true;s.getRange('A30:M32').format.verticalAlignment='top';
w.recalculate();
const ov=w.worksheets.getItem('Объекты').getRange('B32:P32').values[0];if(Math.abs(ov[2]-a.summary.delta)>0.001||Math.abs(ov[11]-a.summary.traffic_effect)>0.001||Math.abs(ov[12]-a.summary.ticket_effect)>0.001)throw Error('Data reconciliation failed '+JSON.stringify(ov));
const ds=w.worksheets.getItem('Данные');const original=ds.getRange('D2').values[0][0];ds.getRange('D2').values=[[original+100]];if(Math.abs(w.worksheets.getItem('Итоги').getRange('B5').values[0][0]-a.summary.revenue2018-100)>0.001)throw Error('Input change did not recalculate');ds.getRange('D2').values=[[original]];
await save(w,'Шоколадница_Анализ',[['Итоги','A1:M33','data_summary'],['Объекты','A1:H16','data_objects'],['Объекты','I4:P16','data_factors'],['По месяцам','A1:G17','data_months'],['Данные','A1:E16','data_source']]);

const sql=await SpreadsheetFile.importXlsx(await FileBlob.load(path.join(root,'data/sql_source.xlsx')));
const q1=await fs.readFile(path.join(root,'sql/01_managers.sql'),'utf8');const q2=await fs.readFile(path.join(root,'sql/02_first_order.sql'),'utf8');
for(const [i,text]of [[0,q1],[1,q2]]){s=sql.worksheets.getItemAt(i);base(s,'A1:G100');s.getRange('A1:A100').format.columnWidth=110;const start=i===0?21:16;title(s,`A${start}`,'Решение (SQL)');const lines=text.split('\n');for(let j=0;j<lines.length;j++)put(s,`A${start+2+j}`,lines[j]);s.getRange(`A${start+2}:A${start+2+lines.length}`).format.font={name:'Consolas',size:11,color:ink};s.getRange('A1:A18').format.wrapText=true;for(const r of i===0?[1,8,9,10]:[1,6,7])s.getRange(`A${r}`).format.rowHeight=r===7?110:45;}
await save(sql,'Шоколадница_SQL',[['Задание 1','A21:A63','sql1'],['Задание 2','A16:A33','sql2']]);
await fs.writeFile(path.join(root,'qa/workbook_validation.json'),JSON.stringify({excel1_total:a.excel1_total,excel3_total:a.excel3_total,table_expansion_test:true,data_input_change_test:true,independent_reconciliation:true},null,2));
console.log('Three workbooks exported. Independent totals, table expansion and live input change verified.');
