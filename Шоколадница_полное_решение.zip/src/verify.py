"""Meaningful SQL edge cases and saved workbook reconciliation."""
from pathlib import Path
import sqlite3, json
import openpyxl
ROOT=Path(__file__).resolve().parents[1]

def queries(filename):
    text=(ROOT/'sql'/filename).read_text(encoding='utf-8')
    return [s.strip() for s in text.split(';') if s.strip()]

def main():
    sql=queries('01_managers.sql'); first=queries('02_first_order.sql')[0]
    con=sqlite3.connect(':memory:')
    con.execute('CREATE TABLE db(user_id INTEGER PRIMARY KEY, boss_user_id INTEGER, payment REAL)')
    con.executemany('INSERT INTO db VALUES (?,?,?)',[(1,2,50000),(5,2,60000),(6,2,70000),(7,2,90000),(2,3,200000)])
    original=[con.execute(q).fetchall() for q in sql]
    assert original==[[(200000.0,)],[(4.0,)],[],[(3,)]]
    con.execute('DELETE FROM db')
    con.executemany('INSERT INTO db VALUES (?,?,?)',[(1,None,100),(2,None,100),(3,1,150),(4,1,100),(5,1,50),(6,2,40),(7,99,999),(8,None,None)])
    assert con.execute(sql[0]).fetchone()[0]==100
    assert con.execute(sql[1]).fetchone()[0]==2
    assert [r[0] for r in con.execute(sql[2])]==[3]
    assert con.execute(sql[3]).fetchall()==[(99,)]
    con.execute('DELETE FROM db');con.execute('INSERT INTO db VALUES (1,NULL,10)')
    assert con.execute(sql[0]).fetchone()[0] is None
    assert con.execute(sql[1]).fetchone()[0] is None
    con.execute('CREATE TABLE Orders(OrderID INTEGER PRIMARY KEY, CustomerID INTEGER NOT NULL, OrderDate DATE)')
    con.executemany('INSERT INTO Orders VALUES (?,?,?)',[(1,2,'2024-03-01'),(20,2,'2024-01-01'),(19,2,'2024-01-01'),(9,1,'2025-01-01'),(10,1,None),(11,3,None)])
    assert con.execute(first).fetchall()==[(1,9),(2,19)]
    a=json.loads((ROOT/'qa/analysis.json').read_text(encoding='utf-8'))
    ex=openpyxl.load_workbook(ROOT/'outputs/Шоколадница_Excel.xlsx',data_only=True)
    assert ex['Порции']['I20'].value==5994
    assert ex['Общий итог']['G3'].value==12578
    for r in range(2,22):
        assert ex['ФИО'][f'D{r}'].value=='Фамилия Имя'
        assert ex['ФИО'][f'E{r}'].value==f'Отчество{r-1}'
        assert ex['ФИО'][f'H{r}'].value=='Фамилия И.О.'
    w=openpyxl.load_workbook(ROOT/'outputs/Шоколадница_Анализ.xlsx',data_only=True)
    assert w['Итоги']['B5'].value==73885075
    assert w['Итоги']['C5'].value==74477846.5
    assert w['Итоги']['B10'].value==592771.5
    assert abs(w['Итоги']['B15'].value)<0.000001
    for row in w['Объекты'].iter_rows(min_row=5,max_row=31,values_only=True):
        control=next(o for o in a['objects'] if o['cafe']==row[0])
        for index,key in [(1,'revenue2018'),(2,'revenue2019'),(3,'delta'),(5,'checks2018'),(6,'checks2019'),(9,'ticket2018'),(10,'ticket2019'),(12,'traffic_effect'),(13,'ticket_effect')]:
            assert abs(row[index]-control[key])<0.00001,(row[0],key)
    out=dict(sql_original_results=original,sql_edge_cases='passed',saved_workbooks='passed',cafes_checked=27,
             original_rows=648,excel1_total=5994,excel3_total=12578)
    (ROOT/'qa/verification.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False))

if __name__=='__main__':main()
